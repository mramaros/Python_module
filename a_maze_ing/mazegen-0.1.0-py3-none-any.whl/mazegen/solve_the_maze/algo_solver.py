#!/usr/bin/env python3
# ########################################################################### #
#   shebang: 1                                                                #
#                                                          :::      ::::::::  #
#   algo_solver.py                                       :+:      :+:    :+:  #
#                                                      +:+ +:+         +:+    #
#   By: raaron-v <raaron-v@student.42antananarivo.   +#+  +:+       +#+       #
#                                                  +#+#+#+#+#+   +#+          #
#   Created: 2026/06/11 17:19:18 by raaron-v            #+#    #+#            #
#   Updated: 2026/07/15 08:15:05 by raaron-v           ###   ########.fr      #
#                                                                             #
# ########################################################################### #

from ..generate_cellule.class_cell import Cell
import random


def solver_in_nesw(solver:list[tuple[int, int]]) -> list[str]:
    nesw = []
    for i in range(len(solver) - 1):
        x = solver[i + 1][0] - solver[i][0]
        y = solver[i + 1][1] - solver[i][1]
        if x == 0 and y == -1:
            nesw.append("N")
        elif x == 1 and y == 0:
            nesw.append("E")
        elif x == 0 and y == 1:
            nesw.append("S")
        elif x == -1 and y == 0:
            nesw.append("W")
    return nesw
