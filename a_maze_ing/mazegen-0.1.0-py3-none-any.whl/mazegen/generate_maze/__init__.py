#!/usr/bin/env python3
# ########################################################################### #
#   shebang: 1                                                                #
#                                                          :::      ::::::::  #
#   __init__.py                                          :+:      :+:    :+:  #
#                                                      +:+ +:+         +:+    #
#   By: raaron-v <raaron-v@student.42antananarivo.   +#+  +:+       +#+       #
#                                                  +#+#+#+#+#+   +#+          #
#   Created: 2026/06/09 06:44:27 by mramaros            #+#    #+#            #
#   Updated: 2026/07/13 23:05:53 by raaron-v           ###   ########.fr      #
#                                                                             #
# ########################################################################### #

from .cellule_isolated import isolated_cells

__all__ = ["isolated_cells"]

