#!/usr/bin/env python3
# ########################################################################### #
#   shebang: 1                                                                #
#                                                          :::      ::::::::  #
#   classe_gamer.py                                      :+:      :+:    :+:  #
#                                                      +:+ +:+         +:+    #
#   By: raaron-v <raaron-v@student.42antananarivo.   +#+  +:+       +#+       #
#                                                  +#+#+#+#+#+   +#+          #
#   Created: 2026/07/13 17:50:52 by raaron-v            #+#    #+#            #
#   Updated: 2026/07/13 22:26:41 by raaron-v           ###   ########.fr      #
#                                                                             #
# ########################################################################### #

class GameState:
    def __init__(self, entry_xy: tuple[int, int], exit_xy: tuple[int, int]):
        self.pos = entry_xy
        self.exit_pos = exit_xy
        self.play_or_not = False
