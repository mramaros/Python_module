#!/usr/bin/env python3
# ########################################################################### #
#   shebang: 1                                                                #
#                                                          :::      ::::::::  #
#   renderer.py                                          :+:      :+:    :+:  #
#                                                      +:+ +:+         +:+    #
#   By: raaron-v <raaron-v@student.42antananarivo.   +#+  +:+       +#+       #
#                                                  +#+#+#+#+#+   +#+          #
#   Created: 2026/06/12 10:52:50 by raaron-v            #+#    #+#            #
#   Updated: 2026/07/20 00:50:34 by raaron-v           ###   ########.fr      #
#                                                                             #
# ########################################################################### #

from .generate_cellule import Cell, get_cell
from .generate_maze import isolated_cells
from typing import Any
import sys
try:
    from mlx import Mlx
except Exception:
    sys.exit("The module mlx could not be found")

class MazeMlx:
    def __init__(self, COLS: int, ROWS: int, width: int, height: int, cell_size: int, outline_thickness: int) -> None:
        self.COLS = COLS
        self.ROWS = ROWS
        self.width = width
        self.height = height
        self.CELL_SIZE = cell_size
        self.OUTLINE_THICKNESS = outline_thickness

        the_width = (self.COLS - self.OUTLINE_THICKNESS) // self.CELL_SIZE
        the_height = (self.ROWS - self.OUTLINE_THICKNESS) // self.CELL_SIZE
        self.isoler = isolated_cells(the_width, the_height)

        self.mlx = Mlx()
        self.mlx_ptr = self.mlx.mlx_init()
        self.win = self.mlx.mlx_new_window(self.mlx_ptr, COLS + 30, ROWS + 80, "A-Maze-ing")
        self.img = self.mlx.mlx_new_image(self.mlx_ptr, COLS, ROWS)

        self.data, self.bpp, self.sl, self.fmt = self.mlx.mlx_get_data_addr(self.img)

    def put_pixel(self, x: int, y: int, color: int) -> None:
        if 0 <= x < self.COLS and 0 <= y < self.ROWS:
            offset = y * self.sl + x * (self.bpp // 8)
            self.data[offset:offset + 4] = color.to_bytes(4, 'little')

    def put_pixel_all_image(self, old_color: int, new_color: int):
        old = old_color.to_bytes(4, "little")
        new = new_color.to_bytes(4, "little")

        for i in range(0, len(self.data), 4):
            if self.data[i:i+4] == old:
                self.data[i:i+4] = new

    def draw_line_h(self, x0: int, y0: int, length: int, color: int, thickness=1) -> None:
        for t in range(thickness):
            for dx in range(length):
                self.put_pixel(x0 + dx, y0 + t, color)

    def draw_line_v(self, x0: int, y0: int, length: int, color: int, thickness=1) -> None:
        for t in range(thickness):
            for dy in range(length):
                self.put_pixel(x0 + t, y0 + dy, color)

    def delet_line_h(self, x0: int, y0: int, length: int, thickness=1, perfect: bool = True) -> None:
        for t in range(thickness):
            if perfect:
                for dx in range(thickness, length):
                    self.put_pixel(x0 + dx, y0 + t, 0xFF000000)
            else:
                for dx in range(length):
                    self.put_pixel(x0 + dx, y0 + t, 0xFF000000)

    def delet_line_v(self, x0: int, y0: int, length: int, thickness=1, perfect: bool = True) -> None:
        for t in range(thickness):
            if perfect:
                for dy in range(thickness, length):
                    self.put_pixel(x0 + t, y0 + dy, 0xFF000000)
            else:
                for dy in range(length):
                    self.put_pixel(x0 + t, y0 + dy, 0xFF000000)

    def color_entry_and_exit(self, ENTRY_X: int, ENTRY_Y: int, EXIT_X: int, EXIT_Y: int):
        for x in range(ENTRY_X, ENTRY_X + self.CELL_SIZE - self.OUTLINE_THICKNESS):
            for y in range(ENTRY_Y, ENTRY_Y + self.CELL_SIZE - self.OUTLINE_THICKNESS):
                self.put_pixel(x, y, 0x1F00FF00)
        for x in range(EXIT_X, EXIT_X + self.CELL_SIZE - self.OUTLINE_THICKNESS):
            for y in range(EXIT_Y, EXIT_Y + self.CELL_SIZE - self.OUTLINE_THICKNESS):
                self.put_pixel(x, y, 0x1FFF0000)

    def color_content_solver(self, all_cell: list[Cell], his_x: int, his_y: int, index: int, solver_slice: list[tuple[int, int]], color: int):
        center_x = his_x * self.CELL_SIZE + self.OUTLINE_THICKNESS + (self.CELL_SIZE - self.OUTLINE_THICKNESS) // 2
        center_y = his_y * self.CELL_SIZE + self.OUTLINE_THICKNESS + (self.CELL_SIZE - self.OUTLINE_THICKNESS) // 2

        if len(solver_slice) > 1:
            next_x, next_y = solver_slice[1]
            next_center_x = next_x * self.CELL_SIZE + self.OUTLINE_THICKNESS + (self.CELL_SIZE - self.OUTLINE_THICKNESS) // 2
            next_center_y = next_y * self.CELL_SIZE + self.OUTLINE_THICKNESS + (self.CELL_SIZE - self.OUTLINE_THICKNESS) // 2

            thickness = self.OUTLINE_THICKNESS + 1
            if center_x == next_center_x:
                y_start = min(center_y, next_center_y)
                length = abs(next_center_y - center_y) + thickness
                self.draw_line_v(center_x - thickness//2 + 1, y_start - thickness//2 + 1, length, color, thickness)
            else:
                x_start = min(center_x, next_center_x)
                length = abs(next_center_x - center_x) + thickness
                self.draw_line_h(x_start - thickness//2 + 1, center_y - thickness//2 + 1, length, color, thickness)

    def color_isoler(self, isoler: list[tuple[int, int]], cell_iso: tuple[int, int], color: int):
        iso_x, iso_y = cell_iso
        px = iso_x * self.CELL_SIZE + self.OUTLINE_THICKNESS
        py = iso_y * self.CELL_SIZE + self.OUTLINE_THICKNESS
        for x in range(px, px + self.CELL_SIZE - self.OUTLINE_THICKNESS):
            for y in range(py, py + self.CELL_SIZE - self.OUTLINE_THICKNESS):
                self.put_pixel(x, y, color)

        if (iso_x + 1, iso_y) in isoler:
            for dy in range(self.CELL_SIZE - self.OUTLINE_THICKNESS):
                for t in range(self.OUTLINE_THICKNESS + 1):
                    self.put_pixel(px + self.CELL_SIZE - self.OUTLINE_THICKNESS + t, py + dy, color)
        if (iso_x - 1, iso_y) in isoler:
            for dy in range(self.CELL_SIZE - self.OUTLINE_THICKNESS):
                for t in range(self.OUTLINE_THICKNESS + 1):
                    self.put_pixel(px - t, py + dy, color)
        if (iso_x, iso_y + 1) in isoler:
            for dx in range(self.CELL_SIZE - self.OUTLINE_THICKNESS):
                for t in range(self.OUTLINE_THICKNESS + 1):
                    self.put_pixel(px + dx, py + self.CELL_SIZE - self.OUTLINE_THICKNESS + t, color)
        if (iso_x, iso_y - 1) in isoler:
            for dx in range(self.CELL_SIZE - self.OUTLINE_THICKNESS):
                for t in range(self.OUTLINE_THICKNESS + 1):
                    self.put_pixel(px + dx, py - t, color)

    def clear_img(self):
        black = 0x1F000000
        for y in range(self.ROWS):
            for x in range(self.COLS):
                self.put_pixel(x, y, black)

    def render_full(self, all_cell: list[Cell], isoler: list[tuple[int, int]], color: int) -> None:
        for c in all_cell:
            if self.width >= 9 and self.height >= 8:
                if (c.x, c.y) not in isoler:
                    x0 = c.x * self.CELL_SIZE
                    y0 = c.y * self.CELL_SIZE

                    self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
            else:
                x0 = c.x * self.CELL_SIZE
                y0 = c.y * self.CELL_SIZE

                self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
        self.mlx.mlx_put_image_to_window(self.mlx_ptr, self.win, self.img, 15, 15)

    def render_cell(self, a_cell: Cell, color: int, do: bool = True) -> None:
        x0 = a_cell.x * self.CELL_SIZE
        y0 = a_cell.y * self.CELL_SIZE

        if do:
            if a_cell.wall[0][0] and a_cell.wall[0][0]:
                self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
            if a_cell.wall[1][0] and a_cell.wall[1][0]:
                self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
            if a_cell.wall[2][0] and a_cell.wall[2][0]:
                self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
            if a_cell.wall[3][0] and a_cell.wall[3][0]:
                self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
        else:
            if self.width >= 9 and self.height >= 8:
                if (a_cell.x, a_cell.y) not in self.isoler:
                    if a_cell.wall[0][0] and a_cell.wall[0][0]:
                        self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    if a_cell.wall[1][0] and a_cell.wall[1][0]:
                        self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    if a_cell.wall[2][0] and a_cell.wall[2][0]:
                        self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    if a_cell.wall[3][0] and a_cell.wall[3][0]:
                        self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

            else:
                if a_cell.wall[0][0] and a_cell.wall[0][0]:
                    self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                if a_cell.wall[1][0] and a_cell.wall[1][0]:
                    self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                if a_cell.wall[2][0] and a_cell.wall[2][0]:
                    self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                if a_cell.wall[3][0] and a_cell.wall[3][0]:
                    self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

    def render(self, all_cell: list[Cell], color: int, do: bool = True) -> None:
        the_width = (self.COLS - self.OUTLINE_THICKNESS) // self.CELL_SIZE
        the_height = (self.ROWS - self.OUTLINE_THICKNESS) // self.CELL_SIZE
        isoler = isolated_cells(the_width, the_height)
        for c in all_cell:
            x0 = c.x * self.CELL_SIZE
            y0 = c.y * self.CELL_SIZE

            if do:
                if c.wall[0][0] and c.wall[0][0]:
                    self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                if c.wall[1][0] and c.wall[1][0]:
                    self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                if c.wall[2][0] and c.wall[2][0]:
                    self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                if c.wall[3][0] and c.wall[3][0]:
                    self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
            else:
                if self.width >= 9 and self.height >= 8:
                    if (c.x, c.y) not in isoler:
                        if c.wall[0][0] and c.wall[0][0]:
                            self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                        if c.wall[1][0] and c.wall[1][0]:
                            self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                        if c.wall[2][0] and c.wall[2][0]:
                            self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                        if c.wall[3][0] and c.wall[3][0]:
                            self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

                else:
                    if c.wall[0][0] and c.wall[0][0]:
                        self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    if c.wall[1][0] and c.wall[1][0]:
                        self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    if c.wall[2][0] and c.wall[2][0]:
                        self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
                    if c.wall[3][0] and c.wall[3][0]:
                        self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

    def draw_cell(self, cell: Cell, color: int, display: bool = False) -> None:
        x0 = cell.x * self.CELL_SIZE
        y0 = cell.y * self.CELL_SIZE

        if cell.wall[0][0] and cell.wall[0][1]:
            self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
        elif cell.wall[0][1]:
            self.delet_line_h(x0, y0, self.CELL_SIZE, self.OUTLINE_THICKNESS)

        if cell.wall[1][0] and cell.wall[1][1]:
            self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
        elif cell.wall[1][1]:
            self.delet_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE, self.OUTLINE_THICKNESS)

        if cell.wall[2][0] and cell.wall[2][1]:
            self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
        elif cell.wall[2][1]:
            self.delet_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE, self.OUTLINE_THICKNESS)

        if cell.wall[3][0] and cell.wall[3][1]:
            self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)
        elif cell.wall[3][1]:
            self.delet_line_v(x0, y0, self.CELL_SIZE, self.OUTLINE_THICKNESS)

        if not display:
            if not cell.wall[0][0] and not cell.wall[0][1]:
                self.draw_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

            if not cell.wall[1][0] and not cell.wall[1][1]:
                self.draw_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

            if not cell.wall[2][0] and not cell.wall[2][1]:
                self.draw_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

            if not cell.wall[3][0] and not cell.wall[3][1]:
                self.draw_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, color, self.OUTLINE_THICKNESS)

    def draw_cell_imperfect(
        self,
        cell: Cell,
        isoler: list[tuple[int, int]],
        color: int,
        ) -> None:
        x0 = cell.x * self.CELL_SIZE
        y0 = cell.y * self.CELL_SIZE

        if self.width >= 9 and self.height >= 8:
            if (cell.x, cell.y) not in isoler:
                if not cell.wall[0][0]:
                    self.delet_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)

                if not cell.wall[1][0]:
                    self.delet_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)

                if not cell.wall[2][0]:
                    self.delet_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)

                if not cell.wall[3][0]:
                    self.delet_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)
                self.draw_cell(cell, color, True)
        else:
            if not cell.wall[0][0]:
                self.delet_line_h(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)

            if not cell.wall[1][0]:
                self.delet_line_v(x0 + self.CELL_SIZE, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)

            if not cell.wall[2][0]:
                self.delet_line_h(x0, y0 + self.CELL_SIZE, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)

            if not cell.wall[3][0]:
                self.delet_line_v(x0, y0, self.CELL_SIZE + self.OUTLINE_THICKNESS, self.OUTLINE_THICKNESS, False)
            self.draw_cell(cell, color, True)

    def fill_cell(self, all_stat: dict[str, Any], x: int, y: int, color: int):
        px = x * self.CELL_SIZE
        py = y * self.CELL_SIZE
        for dx in range(self.OUTLINE_THICKNESS, self.CELL_SIZE):
            for dy in range(self.OUTLINE_THICKNESS, self.CELL_SIZE):
                self.put_pixel(px + dx, py + dy, color)

        a_cell = get_cell(all_stat["all_cell"], x, y, all_stat["WIDTH"])
        self.draw_cell_imperfect(a_cell, all_stat["isoler_original"], all_stat["color"][0])

        if y - 1 >= 0 and (x, y - 1) not in self.isoler:
            a_cell = get_cell(all_stat["all_cell"], x, y - 1, all_stat["WIDTH"])
            self.render_cell(a_cell, all_stat["color"][0])
        if x + 1 < all_stat["WIDTH"] and (x + 1, y) not in self.isoler:
            a_cell = get_cell(all_stat["all_cell"], x + 1, y, all_stat["WIDTH"])
            self.render_cell(a_cell, all_stat["color"][0])
        if y + 1 < all_stat["HEIGHT"] and (x, y + 1) not in self.isoler:
            a_cell = get_cell(all_stat["all_cell"], x, y + 1, all_stat["WIDTH"])
            self.render_cell(a_cell, all_stat["color"][0])
        if x - 1 >= 0 and (x - 1, y) not in self.isoler:
            a_cell = get_cell(all_stat["all_cell"], x - 1, y, all_stat["WIDTH"])
            self.render_cell(a_cell, all_stat["color"][0])
