#!/usr/bin/env python3
# ########################################################################### #
#   shebang: 1                                                                #
#                                                          :::      ::::::::  #
#   generate_cellule.py                                  :+:      :+:    :+:  #
#                                                      +:+ +:+         +:+    #
#   By: raaron-v <raaron-v@student.42antananarivo.   +#+  +:+       +#+       #
#                                                  +#+#+#+#+#+   +#+          #
#   Created: 2026/06/09 06:44:11 by mramaros            #+#    #+#            #
#   Updated: 2026/07/13 23:03:46 by raaron-v           ###   ########.fr      #
#                                                                             #
# ########################################################################### #

from typing import List
from .class_cell import Cell


def get_cell(all_cell: List[Cell], x: int, y: int, WIDTH: int) -> Cell:
    """Retourne la cellule aux coordonnées (x,y) dans la liste linéaire."""
    return all_cell[y * WIDTH + x]
